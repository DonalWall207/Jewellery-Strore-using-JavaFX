package com.example.donalwall.Models;

public class DisplayTray {
    public DisplayTray nextTray;
    private String UID;
    private String materialColour;
    private String width;
    private String depth;
    public JewelleryItem firstItem;


    public DisplayTray(DisplayCase dc, String UID, String materialColour, String width, String depth) {
        this.UID = UID;
        this.materialColour = materialColour;
        this.width = width;
        this.depth = depth;

        this.nextTray=dc.firstTray;
        dc.firstTray=this;

    }

    public DisplayTray getNextTray() {
        return nextTray;
    }

    public void setNextTray(DisplayTray nextTray) {
        this.nextTray = nextTray;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getMaterialColour() {
        return materialColour;
    }

    public void setMaterialColour(String materialColour) {
        this.materialColour = materialColour;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getDepth() {
        return depth;
    }

    public void setDepth(String depth) {
        this.depth = depth;
    }

    @Override
    public String toString() {
        return " DisplayTrayUID( " + UID + '\'' +
                " ) Colour : '" + materialColour + '\'' +
                " width :" + width + '\'' +
                "mm depth :'" + depth + '\'' +
                " mm ";
    }
}
