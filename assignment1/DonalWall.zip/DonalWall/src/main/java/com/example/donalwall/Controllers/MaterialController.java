package com.example.donalwall.Controllers;

import com.example.donalwall.Main;
import com.example.donalwall.Models.Material;
import com.thoughtworks.xstream.XStream;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import com.thoughtworks.xstream.io.xml.DomDriver;

import java.io.*;

public class MaterialController {
    public ChoiceBox<Integer> quality,amount;
    public TextField description,type;
    public ListView<Material> mt;

    public static Material firstMaterial;
    public static Material selectedMaterial;

    public void addMaterial(String type, String description, int quality, int amount) {
        Material ma = new Material(JewelleryItemController.selectedItem, type, description, quality, amount);
        mt.getItems().add(ma);
        ma.setType(type);
        ma.setDescription(description);
        ma.setQuality(quality);
        ma.setAmount(amount);

        Material temp = firstMaterial;
        while (temp != null) {
            System.out.println(temp.getType());
            temp = temp.getNextMaterial();
        }

    }

    public void addMat(ActionEvent actionEvent) {

        addMaterial(type.getText(),description.getText(),quality.getValue(),amount.getValue());
    }

    public void deleteMat(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.BACK_SPACE &&
                mt.getSelectionModel().getSelectedIndex() >= 0)
            mt.getItems().remove(mt.getSelectionModel()
                    .getSelectedIndex());

    }

    public void initialize() {
        quality.getItems().addAll(1,2,3,4,5);
        amount.getItems().addAll(1,2,3,4,5,6);
    }

    public void changeScene2(ActionEvent createItem) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("jewelleryItem.fxml"));
        type.getScene().setRoot(fxmlLoader.load());
    }

    public void selectMaterial(MouseEvent mouseEvent) {
        selectedMaterial = mt.getSelectionModel().getSelectedItem();
    }
}
