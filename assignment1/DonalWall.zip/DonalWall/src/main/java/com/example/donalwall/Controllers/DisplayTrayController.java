package com.example.donalwall.Controllers;

import com.example.donalwall.Models.DisplayCase;
import com.example.donalwall.Models.DisplayTray;
import com.example.donalwall.Main;
import com.thoughtworks.xstream.XStream;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import com.thoughtworks.xstream.io.xml.DomDriver;

import java.io.*;

public class DisplayTrayController {

    public ChoiceBox<String> matColor;
    public TextField UID2, width, depth;
    public ListView<DisplayTray> dty;

    public static DisplayTray firstTray;
    public static DisplayTray selectedTray;

    public void addDisplayTray(String UID, String materialColour, String width, String depth) {
        DisplayTray dt1 = new DisplayTray(Controller.selectedCase, UID, materialColour, width, depth);
        dty.getItems().add(dt1);
        dt1.setUID(UID);
        dt1.setMaterialColour(materialColour);
        dt1.setWidth(width);
        dt1.setDepth(depth);

        DisplayTray temp = firstTray;
        while (temp != null) {
            System.out.println(temp.getUID());
            temp = temp.getNextTray();
        }
    }

    public void addTray(ActionEvent actionEvent) {


        addDisplayTray(UID2.getText(),width.getText(),depth.getText(),matColor.getValue());
    }

    public void deleteTray(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.BACK_SPACE &&
                dty.getSelectionModel().getSelectedIndex() >= 0)
            dty.getItems().remove(dty.getSelectionModel()
                    .getSelectedIndex());

    }

    public void changeScene1(ActionEvent createTray) {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("displayCase.fxml"));
        Scene scene1 = null;
        try {
            scene1 = new Scene(fxmlLoader.load());
        } catch (IOException e) {
            e.printStackTrace();
        }
        Stage s = (Stage) ((Button) createTray.getSource()).getScene().getWindow();
        s.setScene(scene1);
    }


    public void changeScene2(ActionEvent createItem) throws IOException{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("jewelleryItem.fxml"));
        UID2.getScene().setRoot(fxmlLoader.load());
    }

    public void initialize() {
        matColor.getItems().addAll("Red", "Green", "Blue", "Yellow");
    }

    public void selectItem(MouseEvent mouseEvent) throws IOException {
        if (mouseEvent.getClickCount() == 2) {
            selectedTray = dty.getSelectionModel().getSelectedItem();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("jewelleryItem.fxml"));
            dty.getScene().setRoot(fxmlLoader.load());

        }
    }
}



