package com.example.donalwall.Controllers;

import com.example.donalwall.Models.DisplayCase;
import com.example.donalwall.Models.JewelleryItem;
import com.example.donalwall.Main;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.*;

public class JewelleryItemController {

    public ChoiceBox<String> gender;
    public TextField description, type, URL, retailPrice;
    public ListView<JewelleryItem> ji;

    public static JewelleryItem firstItem;
    public static JewelleryItem selectedItem;

    public void addJewelleryItem(String itemDescription, String type, String gender, String URL, int retailPrice) {
        JewelleryItem ji1 = new JewelleryItem(DisplayTrayController.selectedTray, itemDescription, type, gender, URL, retailPrice);
        ji.getItems().add(ji1);
        ji1.setItemDescription(itemDescription);
        ji1.setType(type);
        ji1.setGender(gender);
        ji1.setURL(URL);
        ji1.setRetailPrice(retailPrice);

        JewelleryItem temp = firstItem;
        while (temp != null) {
            System.out.println(temp.getItemDescription());
            temp = temp.getNextItem();
        }

    }

    public void addItem(ActionEvent actionEvent) {

        addJewelleryItem(description.getText(),type.getText(),gender.getValue(),URL.getText(),retailPrice.getPrefColumnCount());

    }

    public void deleteItem(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.BACK_SPACE &&
                ji.getSelectionModel().getSelectedIndex() >= 0)
            ji.getItems().remove(ji.getSelectionModel()
                    .getSelectedIndex());

    }


    public void changeScene(ActionEvent createCase) {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("displayTray.fxml"));
        Scene scene = null;
        try {
            scene = new Scene(fxmlLoader.load());

        } catch (IOException e) {
            e.printStackTrace();
        }
        Stage s = (Stage) ((Button) createCase.getSource()).getScene().getWindow();
        s.setScene(scene);

    }

    public void changeScene3(ActionEvent createMaterial) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("material.fxml"));
        URL.getScene().setRoot(fxmlLoader.load());
    }

    public void initialize() {
        gender.getItems().addAll("Male", "Female");
    }

    public void selectItem(MouseEvent mouseEvent) throws IOException {
        if (mouseEvent.getClickCount() == 2) {
            selectedItem = ji.getSelectionModel().getSelectedItem();
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("material.fxml"));
            ji.getScene().setRoot(fxmlLoader.load());
        }
    }

}
